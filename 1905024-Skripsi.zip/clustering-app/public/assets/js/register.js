$(function () {
    getListDistrict();
    getListType();
});
