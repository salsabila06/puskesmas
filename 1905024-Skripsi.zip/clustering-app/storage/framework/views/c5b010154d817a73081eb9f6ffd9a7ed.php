<?php $__env->startSection('title'); ?>
    Isi Survey
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4>Table Survey</h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive">
                        <table id="table" width="100%">
                            <thead>
                                <th>#</th>
                                <th>Judul</th>
                                <th>Tanggal Terbit</th>
                                <th>Aksi</th>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('assets/js/isi_survey.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.input_survey.partials.modal_result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/pages/input_survey/index.blade.php ENDPATH**/ ?>