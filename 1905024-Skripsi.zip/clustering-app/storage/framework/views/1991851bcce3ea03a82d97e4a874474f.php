<?php $__env->startSection('title'); ?>
    Daftar Survey
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .folder:hover {
            background-color: gainsboro;
            cursor: pointer;
            border-radius: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-start align-items-center">

        <?php $__empty_1 = true; $__currentLoopData = $survey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-sm-2 col-md-2 col-lg-2 col-xl-2">
                <a href="/result/<?php echo e($item->id_survey); ?>" class="text-decoration-none text-monospace text-dark">
                    <div class="text-center p-1 folder">
                        <iconify-icon icon="material-symbols:folder" class="text-warning" width="100"></iconify-icon>
                        <p class="text-truncate text-black font-weight-bold" data-toggle="tooltip" data-placement="bottom"
                            title="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></p>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <div class="col-12 text-center p-3">
                <iconify-icon icon="mdi:file-document-alert" width="100" class="text-danger"></iconify-icon>
                <h6 class="my-3">Survey Belum Tersedia.<br> Silahkan tambahkan survey terlebih dahulu</h6>
                <a href="/survey" class="btn btn-primary">Tambah Survey</a>
            </div>
        <?php endif; ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/pages/hasil_survey/index.blade.php ENDPATH**/ ?>