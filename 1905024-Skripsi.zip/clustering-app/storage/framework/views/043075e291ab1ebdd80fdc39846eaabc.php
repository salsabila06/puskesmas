<?php $__env->startSection('title'); ?>
    Isi Survey
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4><?php echo e($survey->title); ?></h4>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">

                    <div class="form-group row">

                        <div class="col">
                            <label for="">Kode Registrasi Puskesmas</label>
                            <input type="text" class="form-control" placeholder="" aria-describedby="helpId" readonly
                                value="<?php echo e($faskes->faskes_code); ?>">
                        </div>
                        <div class="col">
                            <label for="">Nama Puskesmas</label>
                            <input type="text" class="form-control" placeholder="" aria-describedby="helpId" readonly
                                value="<?php echo e($faskes->faskes_name); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col">
                            <label for="">Tipe Puskesmas</label>
                            <input type="text" class="form-control" placeholder="" aria-describedby="helpId" readonly
                                value="<?php echo e($faskes->type->faskes_type_name); ?>">
                        </div>
                        <div class="col">
                            <label for="">Tanggal Puskesmas Didirikan</label>
                            <input type="text" class="form-control" placeholder="" aria-describedby="helpId" readonly
                                value="<?php echo e(date('d-m-Y', strtotime($faskes->faskes_establish))); ?>">
                        </div>
                        <div class="col">
                            <label for="">Kecamatan</label>
                            <input type="text" class="form-control" placeholder="" aria-describedby="helpId" readonly
                                value="<?php echo e($district->district_name); ?>">
                        </div>
                    </div>

                    <hr class="mb-3">
                    <form action="#" id="formSurvey">
                        <input type="hidden" name="id_survey" value="<?php echo e($survey->id_survey); ?>">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <th>No</th>
                                    <th>Parameter</th>
                                    <th>Pilihan</th>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $survey->quest_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="3">
                                                <b><?php echo e(App\Http\Controllers\Controller::numberToRoman($loop->iteration) . '. ' . $item['quest_type_name']); ?></b>
                                            </td>
                                        </tr>

                                        <?php

                                            $data = \Illuminate\Support\Arr::where($survey->quest, function ($value) use ($item) {
                                                return $value->quest_type_id == $item['id_quest_type'];
                                            });
                                        ?>


                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($value->quest); ?></td>
                                                <td>
                                                    <div class="d-flex">
                                                        <div class="custom-control custom-radio mr-3">
                                                            <input type="radio"
                                                                id="yes-<?php echo e($item['quest_type_name'] . $value->id_quest); ?>"
                                                                name="<?php echo e($item['quest_type_name'] . $value->id_quest); ?>"
                                                                value="1" class="custom-control-input">
                                                            <label class="custom-control-label"
                                                                for="yes-<?php echo e($item['quest_type_name'] . $value->id_quest); ?>">YA/ADA</label>
                                                        </div>
                                                        <div class="custom-control custom-radio">
                                                            <input type="radio"
                                                                id="no-<?php echo e($item['quest_type_name'] . $value->id_quest); ?>"
                                                                name="<?php echo e($item['quest_type_name'] . $value->id_quest); ?>"
                                                                value="0" class="custom-control-input">
                                                            <label class="custom-control-label"
                                                                for="no-<?php echo e($item['quest_type_name'] . $value->id_quest); ?>">Tidak</label>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="text-right">
                            <button class="btn btn-success" id="send" disabled type="submit">Kirim Survey</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            $(function() {


                let radio = $(`input[type=radio]`)
                let button = $('#send')
                radio.each((i, v) => {
                    $(v).on('change', function() {
                        let checkedRadio = $(`input[type=radio]:checked`)

                        if ((radio.length / 2) == checkedRadio.length) {
                            button.prop('disabled', false)
                        }
                    })
                })

                $('#formSurvey').on('submit', function(e) {
                    e.preventDefault()

                    ajax("/input-survey", $(this).serialize()).done((res) => {
                        Notiflix.Report.success(
                            'Survey berhasil disimpan',
                            'Terima kasih sudah mengisi survey ini.',
                            'Tutup',
                            function cb() {
                                window.location.href = '/input-survey'
                            });
                    })
                })

               
            })
        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/pages/lets_survey/index.blade.php ENDPATH**/ ?>