<?php $__env->startSection('title'); ?>
    Hasil Survey
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h4>Table Hasil Survey</h4>
            <?php if(!$is_clustered): ?>
                <button class="btn btn-success ml-auto" data-faskes="<?php echo e($faskes_count); ?>" data-pass="<?php echo e($faskes_pass_count); ?>"
                    data-survey="<?php echo e(request()->segment(2)); ?>" id="cluster">Cluster</button>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    <div class="mb-3">
                        <h6>Jumlah Puskesmas : <?php echo e($faskes_pass_count); ?> / <?php echo e($faskes_count); ?></h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table" id="table" width="100%">
                            <thead>
                                <th>#</th>
                                <th>Nama Puskesmas</th>
                                <?php $__currentLoopData = $survey; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($item->quest_type->quest_type_name); ?>(%)</th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->faskes_name); ?></td>
                                        <?php $__currentLoopData = $item->result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($value); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <?php $__env->startPush('js'); ?>
        <script src="<?php echo e(asset('assets/js/cluster.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/pages/hasil_survey_detail/index.blade.php ENDPATH**/ ?>