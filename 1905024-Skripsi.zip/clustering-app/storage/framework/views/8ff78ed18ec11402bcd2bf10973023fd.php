 <div class="main-sidebar">
     <aside id="sidebar-wrapper">
         <div class="sidebar-brand">
             <a href="/" class="text-success">CLUSTERING</a>
         </div>
         <div class="sidebar-brand sidebar-brand-sm">
             <a href="/">CT</a>
         </div>
         <ul class="sidebar-menu">
             <li class="menu-header">Menu</li>
             <?php $__currentLoopData = $sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li class="<?php echo e(request()->segment(1) == str_replace('/', '', $item->menu->menu_url) ? 'active' : ''); ?> ">
                     <a class="nav-link" href="<?php echo e($item->menu->menu_url); ?>">
                         <iconify-icon icon="<?php echo e($item->menu->menu_icon); ?>"
                             style="width: 28px; margin-right: 20px; text-align: center;"></iconify-icon>
                         <span><?php echo e($item->menu->menu_name); ?></span>
                     </a>
                 </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         </ul>
     </aside>
 </div>
<?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>