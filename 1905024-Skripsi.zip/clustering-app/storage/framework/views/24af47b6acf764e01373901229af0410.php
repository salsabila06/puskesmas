<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="username">Username</label>
            <input id="username" type="text" class="form-control" name="username"
                value="<?php echo e(old('username') ?? session('username')); ?>" tabindex="1" autofocus>
        </div>
        <div class="form-group">
            <div class="d-block">
                <label for="password" class="control-label">Password</label>
            </div>
            <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
        </div>

        <div class="form-group text-right">
            
            <button type="submit" class="btn btn-success btn-lg btn-icon icon-right" tabindex="4">
                Login
            </button>
        </div>

        
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>