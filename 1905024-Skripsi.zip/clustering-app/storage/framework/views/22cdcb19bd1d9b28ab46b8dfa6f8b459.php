<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role_id == ROLE_DINAS): ?>
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-warning">
                        <iconify-icon icon="healthicons:i-exam-multiple-choice" class="text-white" width="30">
                        </iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Komponen</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($quest_type); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-success">
                        <iconify-icon icon="mingcute:hospital-fill" class="text-white" width="30"></iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Puskesmas</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($faskes); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-primary">
                        <iconify-icon icon="wpf:survey" class="text-white" width="30"></iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Survey</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($survey); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-info">
                        <iconify-icon icon="fluent:book-question-mark-24-filled" class="text-white" width="30">
                        </iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Pertanyaan</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($quest); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header align-items-center">
                        <h4>Grafik Cluster</h4>
                        <div class="ml-auto w-25">
                            <select class="custom-select" name="" id="survey-select">
                                <?php $__empty_1 = true; $__currentLoopData = $survey_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($item->survey_id); ?>" <?php echo e($loop->index == 0 ? 'selected' : ''); ?>>
                                        <?php echo e($item->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="" selected disabled>Belum Ada Survey</option>
                                <?php endif; ?>
                            </select>

                        </div>

                    </div>
                    <div class="card-body">
                        <canvas id="chart-pie" height="400"></canvas>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-primary">
                        <iconify-icon icon="wpf:survey" class="text-white" width="30"></iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Survey</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($survey); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-success">
                        <iconify-icon class="text-white" width="30"
                            icon="streamline:interface-file-clipboard-check-checkmark-edit-task-edition-checklist-check-success-clipboard-form">
                        </iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Survey Selesai</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($survey_passed); ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-warning">
                        <iconify-icon icon="bi:clipboard-x" class="text-white" width="30"></iconify-icon>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Survey Belum</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($not_yet_survey); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php $__env->startPush('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.0/dist/chart.umd.min.js"></script>
        <script src="<?php echo e(asset('assets/js/chart.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/pages/home/index.blade.php ENDPATH**/ ?>