<footer class="main-footer">
    
</footer>
<?php /**PATH E:\Skripsi\puskesmas\clustering-app\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>